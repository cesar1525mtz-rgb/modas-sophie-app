import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/app_theme.dart';
import 'core/supabase_config.dart';
import 'features/auth/login_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (SupabaseConfig.isConfigured) {
    await Supabase.initialize(
      url: SupabaseConfig.url,
      anonKey: SupabaseConfig.anonKey,
    );
  }

  runApp(const ModasSophieApp());
}

class ModasSophieApp extends StatelessWidget {
  const ModasSophieApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Modas Sophie',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    home: const LoginPage(),
  );
}
