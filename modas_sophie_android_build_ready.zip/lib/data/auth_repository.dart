import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/app_user.dart';

class AuthRepository {
  final SupabaseClient client;
  AuthRepository(this.client);

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await client.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signOut() => client.auth.signOut();

  Future<AppUser> currentProfile() async {
    final id = client.auth.currentUser!.id;
    final row = await client.from('user_profiles').select().eq('id', id).single();
    return AppUser.fromMap(row);
  }
}
