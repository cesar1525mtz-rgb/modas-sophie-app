import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/supabase_config.dart';
import '../../data/auth_repository.dart';
import '../home/owner_dashboard_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> login() async {
    if (!SupabaseConfig.isConfigured) {
      setState(() => error = 'Configura Supabase para iniciar sesión.');
      return;
    }

    setState(() { loading = true; error = null; });
    try {
      final repo = AuthRepository(Supabase.instance.client);
      await repo.signIn(email: email.text.trim(), password: password.text);
      final profile = await repo.currentProfile();

      if (!profile.active) {
        await repo.signOut();
        throw Exception('Usuario inactivo');
      }

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => OwnerDashboardPage(profile: profile)),
      );
    } catch (_) {
      setState(() => error = 'No fue posible iniciar sesión.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 40),
          Center(
            child: ClipOval(
              child: Image.asset(
                'assets/images/logo_modas_sophie.png',
                width: 190,
                height: 190,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text('MODAS SOPHIE',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w800,
            )),
          const Text('Estilo que te define', textAlign: TextAlign.center),
          const SizedBox(height: 40),
          TextField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Correo',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: password,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'Contraseña',
              border: OutlineInputBorder(),
            ),
          ),
          if (error != null) Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(error!, textAlign: TextAlign.center),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: loading ? null : login,
            child: Text(loading ? 'ENTRANDO...' : 'INICIAR SESIÓN'),
          ),
        ],
      ),
    ),
  );
}
